<template>
  <div class="sidebar">
    Standard Sidebar
  </div>
</template>

<script>
export default {
  name: 'Standard',
};
</script>

<style scoped>
  .sidebar {
    font-size: 50px;
    transform: rotate(90deg);
  }
</style>
